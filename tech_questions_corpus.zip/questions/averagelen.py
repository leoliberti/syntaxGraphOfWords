import os
avg = 0
n = 0
# Ouvrir le fichier en lecture
with open('questions.lst', 'r') as file:
    # Lire les lignes une par une
    for i, line in enumerate(file):
        avg += len(line.split())
        n += 1
        
print("avg question length =", avg / n)
