import os

# Ouvrir le fichier en lecture
with open('questions.lst', 'r') as file:

    # Lire les lignes une par une
    for i, line in enumerate(file):
        # Construire le nom de fichier pour chaque ligne
        filename = "question-" + str(i+1).zfill(3) + ".txt"
        
        # Écrire la ligne dans un fichier séparé
        with open(filename, 'w') as outfile:
            outfile.write(line)
